===== USB 参考资料 =====

2008 年 3 月 7 日

对于位于 `Documentation/usb/*` 的 README 文件之外的 USB 相关帮助，请参考以下资源：

- Linux-USB 项目：http://www.linux-usb.org  
  镜像站点在：http://usb.in.tum.de/linux-usb/  
  和 http://it.linux-usb.org
- Linux USB 指南：http://linux-usb.sourceforge.net
- Linux-USB 设备概览（包括可用设备和驱动程序）：
  http://www.qbik.ch/usb/devices/

Linux-USB 邮件列表地址为：linux-usb@vger.kernel.org
