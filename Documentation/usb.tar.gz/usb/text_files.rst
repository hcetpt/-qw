Linux CDC ACM inf
-----------------

.. include:: linux-cdc-acm.inf
    :literal:

Linux inf
---------

.. include:: linux.inf
    :literal:

USB devfs drop permissions source
---------------------------------

.. literalinclude:: usbdevfs-drop-permissions.c
    :language: c

Credits
-------

.. include:: CREDITS
    :literal:
